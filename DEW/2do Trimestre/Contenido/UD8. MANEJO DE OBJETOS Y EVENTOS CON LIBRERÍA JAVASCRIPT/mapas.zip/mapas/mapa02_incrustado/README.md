Leaflet Example
--

Example of creating an interactive map with [Leaflet](http://leafletjs.com) and [OpenStreetMap](https://www.openstreetmap.org).

See my blog post for details: http://asmaloney.com/2014/01/code/creating-an-interactive-map-with-leaflet-and-openstreetmap/

(The image icons came from here: [clker.com](http://www.clker.com/clipart-google-maps-pin-blue.html))

23 January 2014  
Andy Maloney  
https://asmaloney.com
